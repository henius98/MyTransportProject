import { getFirebaseApp, firebaseSdkBase } from "./firebase-config.js";
import { clearConnections } from "./google-token-store.js";

let unsubscribeAuthStateChanged = null;
let authContextPromise = null;
let resolvedAuthContext = null;
let oneTapStarted = false;
let oneTapCancelled = false;
let googleIdentity = null;
let googleIdentityPromise = null;

export async function loadGoogleIdentity() {
  if (window.google?.accounts) return window.google.accounts;
  if (!googleIdentityPromise) {
    googleIdentityPromise = new Promise((resolve, reject) => {
      const script = document.createElement("script");
      script.src = "https://accounts.google.com/gsi/client";
      script.async = true;
      script.onload = () => resolve(window.google.accounts);
      script.onerror = () =>
        reject(
          new Error("Google authorization could not load. Please try again."),
        );
      document.head.appendChild(script);
    });
    void googleIdentityPromise.catch(() => {
      googleIdentityPromise = null;
    });
  }
  return googleIdentityPromise;
}

export function cancelOneTap() {
  oneTapCancelled = true;
  googleIdentity?.cancel();
}

export async function initializeOneTap(clientId) {
  if (oneTapStarted || oneTapCancelled || !clientId?.trim()) return;
  oneTapStarted = true;

  try {
    const { auth, sdk } = await getAuthContext();
    await auth.authStateReady();
    if (auth.currentUser || oneTapCancelled) return;

    // Load Google's UI only after Firebase has restored the visitor's session.
    const identity = await loadGoogleIdentity();
    if (auth.currentUser || oneTapCancelled) return;

    googleIdentity = identity.id;
    googleIdentity.initialize({
      client_id: clientId.trim(),
      auto_select: false,
      callback: async ({ credential }) => {
        if (auth.currentUser || oneTapCancelled) return;
        oneTapCancelled = true;
        try {
          await sdk.signInWithCredential(
            auth,
            sdk.GoogleAuthProvider.credential(credential),
          );
        } catch (error) {
          console.warn(
            "Google One Tap sign-in failed. Use the sign-in button to try again.",
            error.code,
          );
        }
      },
    });
    googleIdentity.prompt();
  } catch (error) {
    console.warn(
      "Google One Tap is unavailable. The sign-in button is still available.",
      error.message,
    );
  }
}

export async function getAuthContext() {
  if (resolvedAuthContext) {
    return resolvedAuthContext;
  }

  if (!authContextPromise) {
    const pending = Promise.all([
      getFirebaseApp(),
      import(`${firebaseSdkBase}/firebase-auth.js`),
    ]).then(([app, sdk]) => {
      const auth = sdk.getAuth(app);
      let previousUid;
      // Clear saved Google access even when no Calendar or Tasks page has been opened.
      sdk.onAuthStateChanged(auth, (user) => {
        const uid = user?.uid ?? null;
        if (uid) cancelOneTap();
        if (!uid || (previousUid !== undefined && previousUid !== uid))
          clearConnections();
        previousUid = uid;
      });
      const provider = new sdk.GoogleAuthProvider();
      provider.setCustomParameters({ prompt: "select_account" });
      const context = { auth, provider, sdk };
      resolvedAuthContext = context;
      return context;
    });
    authContextPromise = pending;
    void pending.catch(() => {
      if (authContextPromise === pending) authContextPromise = null;
      resolvedAuthContext = null;
    });
  }

  return authContextPromise;
}

function userProfile(user) {
  return user
    ? {
        uid: user.uid,
        email: user.email,
        displayName: user.displayName,
        photoURL: user.photoURL,
      }
    : null;
}

export async function requireSignedInUser(uid) {
  const { auth } = await getAuthContext();
  if (!uid || auth.currentUser?.uid !== uid) {
    throw new Error("The signed-in account has changed. Please retry.");
  }
}

export async function signInWithGoogle(explicitClientId) {
  try {
    cancelOneTap();
    const { auth, provider, sdk } =
      resolvedAuthContext || (await getAuthContext());
    const app = await getFirebaseApp();
    const clientId =
      explicitClientId?.trim() ||
      app.options?.googleClientId?.trim();

    if (clientId) {
      try {
        const identity = await loadGoogleIdentity();
        if (identity?.oauth2?.initTokenClient) {
          const user = await new Promise((resolve, reject) => {
            const tokenClient = identity.oauth2.initTokenClient({
              client_id: clientId,
              scope: "email profile openid",
              callback: async (tokenResponse) => {
                if (tokenResponse.error) {
                  const error = new Error(
                    tokenResponse.error_description || tokenResponse.error,
                  );
                  error.code =
                    tokenResponse.error === "access_denied"
                      ? "auth/popup-closed-by-user"
                      : tokenResponse.error;
                  reject(error);
                  return;
                }
                try {
                  const credential = sdk.GoogleAuthProvider.credential(
                    null,
                    tokenResponse.access_token,
                  );
                  const result = await sdk.signInWithCredential(
                    auth,
                    credential,
                  );
                  resolve(result.user);
                } catch (err) {
                  reject(err);
                }
              },
              error_callback: (err) => {
                const error = new Error(
                  err.message || "Google sign-in was cancelled.",
                );
                error.code =
                  err.type === "popup_failed_to_open"
                    ? "auth/popup-blocked"
                    : "auth/popup-closed-by-user";
                reject(error);
              },
            });
            tokenClient.requestAccessToken({ prompt: "select_account" });
          });
          // Result includes credential and user info; only send the profile to Blazor.
          return userProfile(user);
        }
      } catch (gisError) {
        if (
          gisError?.code === "auth/popup-closed-by-user" ||
          gisError?.code === "auth/popup-blocked"
        ) {
          throw gisError;
        }
        console.warn("Google Identity Services unavailable; falling back to popup.", gisError);
      }
    }

    const result = await sdk.signInWithPopup(auth, provider);
    // Result includes credential and user info; only send the profile to Blazor.
    return userProfile(result.user);
  } catch (error) {
    if (error?.code !== "auth/popup-closed-by-user") {
      console.error("Firebase Auth Error:", error);
    }
    throw error;
  }
}

export async function signOut() {
  try {
    cancelOneTap();
    googleIdentity?.disableAutoSelect();
    const { auth, sdk } = await getAuthContext();
    if (auth.currentUser && typeof localStorage !== "undefined" &&
      (localStorage?.getItem("push-token") || localStorage?.getItem("push-uid"))) {
      try {
        const { disable } = await import("./push-notifications.js");
        await disable(auth.currentUser.uid);
      } catch (err) {
        console.warn("Failed to unregister push notifications during sign-out:", err);
      }
    }
    await sdk.signOut(auth);
    clearConnections();
    return true;
  } catch (error) {
    console.error("Firebase SignOut Error:", error);
    throw error;
  }
}

// Allows Blazor to listen to auth state changes
export async function onAuthStateChanged(dotNetHelper) {
  const { auth, sdk } = await getAuthContext();

  if (unsubscribeAuthStateChanged) {
    unsubscribeAuthStateChanged();
  }

  unsubscribeAuthStateChanged = sdk.onAuthStateChanged(auth, (user) => {
    // Pass basic user info to Blazor
    void dotNetHelper
      .invokeMethodAsync("OnAuthStateChanged", userProfile(user))
      .catch((error) =>
        console.error("Could not update the sign-in display:", error),
      );
  });
}

export function disposeAuthStateChanged() {
  cancelOneTap();
  if (unsubscribeAuthStateChanged) {
    unsubscribeAuthStateChanged();
    unsubscribeAuthStateChanged = null;
  }
}
